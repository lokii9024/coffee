let popup = document.querySelector(".popup")

function openpopup(){
    popup.classList.add("open-popup")
}

function closepopup(){
    popup.classList.remove("open-popup")
}